<?php
include('includes/config.php');
?>

<!DOCTYPE html>
<html lang="zxx">
<head>
    <title>Blood Bank and Organ Donation Management System | Search Blood Donor</title>
    <!-- Meta tag Keywords -->
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!--// Meta tag Keywords -->

    <!-- Custom-Files -->
    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/fontawesome-all.css">
</head>

<body>
    <?php include('includes/header.php');?>

    <div class="inner-banner-w3ls">
        <div class="container"></div>
    </div>

    <div class="breadcrumb-agile">
        <div aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="index.php">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">Organ-Donor-List</li>
            </ol>
        </div>
    </div>

    
    <div class="agileits-contact py-5">
        <form name="donar" method="post" style="padding-left: 30px;">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="font-italic">Organ<span style="color:red">*</span></div>
                    <div>
                        <select name="organ" class="form-control" required>
                        <?php $sql = "SELECT * from  tblorgan ";
                        $query = $dbh -> prepare($sql);
                        $query->execute();
                        $results=$query->fetchAll(PDO::FETCH_OBJ);
                        $cnt=1;
                        if($query->rowCount() > 0)
                        {
                        foreach($results as $result)
                        {               ?>  
                        <option value="<?php echo htmlentities($result->Organ);?>"><?php echo htmlentities($result->Organ);?></option>
                        <?php }} ?>
</select>
                        </select>
                    </div>
                </div>

                <div class="col-lg-4 mb-4">
                    <div class="font-italic">Location </div>
                    <div><textarea class="form-control" name="location"></textarea></div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div><input type="submit" name="sub" class="btn btn-primary" value="Submit" style="cursor:pointer"></div>
                </div>
            </div>
        </form>

        <div class="agileits-contact py-5">
        <div class="py-xl-5 py-lg-3">
<?php
    if (isset($_POST['sub'])) {
        $status = 1;
        $organType = $_POST['organ']; 
        $location = $_POST['location'];
        $sql = "SELECT * FROM tblorgandonars WHERE (status = :status AND OrganType = :organType) OR (Address LIKE :location)";
        $query = $dbh->prepare($sql);
        $query->bindParam(':status', $status, PDO::PARAM_INT);
        $query->bindParam(':organType', $organType, PDO::PARAM_STR);
        $locationParam = "%{$location}%"; 
        $query->bindParam(':location', $locationParam, PDO::PARAM_STR);
        $query->execute();
        $results = $query->fetchAll(PDO::FETCH_OBJ);
        
        if ($query->rowCount() > 0) { ?>
            <div class="w3ls-titles text-center mb-5">
                <h3 class="title">Search Organ Donor</h3>
                <span>
                    <i class="fas fa-user-md"></i>
                </span>
            </div>
            <div class="d-flex">
                <div class="row package-grids mt-5" style="padding-left: 50px;">
                    <?php foreach ($results as $result) { ?>
                        <div class="col-md-6 pricing">
                            <div class="price-top">
                                <a href="single.html">
                                    <img src="images/blood-donor.jpg" alt="Blood Donor" style="border:1px #000 solid" class="img-fluid" />
                                </a>
                                <h3><?php echo htmlentities($result->FullName); ?></h3>
                            </div>
                            <div class="price-bottom p-4">
                                <table class="table table-bordered">
                                    <tbody>
                                        <tr>
                                            <th>Gender</th>
                                            <td><?php echo htmlentities($result->Gender); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Blood Group</td>
                                            <td><?php echo htmlentities($result->BloodGroup); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Organ Type</td>
                                            <td><?php echo htmlentities($result->OrganType); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Mobile No.</td>
                                            <td><?php echo htmlentities($result->MobileNumber); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Email ID</td>
                                            <td><?php echo htmlentities($result->EmailId); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Age</td>
                                            <td><?php echo htmlentities($result->Age); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Address</td>
                                            <td><?php echo htmlentities($result->Address); ?></td>
                                        </tr>
                                        <tr>
                                            <td>Message</td>
                                            <td><?php echo htmlentities($result->Message); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                                <a class="btn btn-primary" style="color:#fff" href="contact-organ.php?cid=<?php echo $result->id; ?>">Request</a>
                            </div>
                        </div>
                    <?php } ?>
                </div>
            </div>
        <?php } else {
            echo htmlentities("No Record Found");
        }
    } ?>
</div>

            <!-- //contact -->

            <?php include('includes/footer.php'); ?>

            <!-- Js files -->
            <script src="js/jquery-2.2.3.min.js"></script>
            <script src="js/bootstrap.js"></script>
        </body>
    </html>
